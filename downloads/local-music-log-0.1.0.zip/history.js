export const initialState = () => ({ history: [], paused: false, tabId: null, last: null, status: 'Choose a YouTube Music tab to begin.' });
export function validSample(value) {
    if (!value || typeof value !== 'object')
        return false;
    const s = value;
    try {
        const u = new URL(s.source);
        if (u.origin !== 'https://music.youtube.com' || u.pathname !== '/watch' || !u.searchParams.get('v'))
            return false;
    }
    catch {
        return false;
    }
    return [s.title, s.artist].every(x => typeof x === 'string' && x.trim().length > 0 && x.length <= 500) && typeof s.playing === 'boolean' && typeof s.ended === 'boolean' && Number.isFinite(s.position) && s.position >= 0 && Number.isFinite(s.duration) && s.duration >= 0;
}
export function record(state, s, now = new Date().toISOString()) {
    if (state.paused)
        return state;
    const previous = state.last;
    const changed = !previous || previous.source !== s.source || previous.title !== s.title || previous.artist !== s.artist;
    // A reset near the end can also be a seek. Only count a same-track restart
    // after an observed ended event; prefer missing an ambiguous repeat to inventing one.
    const repeat = previous?.ended && s.playing && s.position < 3;
    let history = state.history;
    if (s.playing && (changed || repeat))
        history = [...history, { title: s.title, artist: s.artist, source: s.source, observedAt: now, id: crypto.randomUUID() }].slice(-300);
    // Do not consume a new track while it is paused/buffering before first playback.
    const last = !s.playing && changed ? previous : s;
    return { ...state, history, last, status: s.playing ? 'Listening to the selected tab.' : 'Playback paused or buffering.' };
}
